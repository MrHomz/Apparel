﻿using System;
using System.Collections.Generic; 
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;

namespace ApparelSystem.Connection
{
    internal class Connection
    {
        public static OleDbConnection conn;
        private static string dbconnection = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= "
             + Application.StartupPath + "\\ApparelDatabase.accdb";

        public static void DB()
        {
            try
            {
                conn = new OleDbConnection(dbconnection);
                conn.Open();
            }
            catch (Exception e)
            {
                conn.Close();
                MessageBox.Show(e.Message);
            }

        }
    }
}

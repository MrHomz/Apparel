﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;


namespace ApparelSystem
{
    public partial class Form1 : Form
    {
        public static string sendtext;
        public Form1()
        {
            InitializeComponent();

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            try
            {
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "Select * from Accounts where username = '" + txtusername.Text
                    + "' and password = '" + txtpassword.Text + "' ";
                DBHelper.DBHelper.command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn);
                DBHelper.DBHelper.reader = DBHelper.DBHelper.command.ExecuteReader();

                if (DBHelper.DBHelper.reader.HasRows)
                {
                    DBHelper.DBHelper.reader.Read();
                    txtusername.Text = (DBHelper.DBHelper.reader["username"].ToString());
                    txtpassword.Text = (DBHelper.DBHelper.reader["password"].ToString());
                    MessageBox.Show("Login successful!", "Access Granted", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    if (txtusername.Text == "admin" && txtpassword.Text == "admin")
                    {
                        sendtext = txtusername.Text;


                        timer1.Enabled = true;
                        timer1.Start();
                        timer1.Interval = 1;
                        progressBar1.Maximum = 200;
                        timer1.Tick += new EventHandler(timer1_Tick);
                    }
                }
                else if (txtusername.Text != "admin" && txtpassword.Text != "admin")
                {
                    Connection.Connection.DB();
                    DBHelper.DBHelper.gen = "SELECT * FROM Customer WHERE username = '" + txtusername.Text + "' AND password = '" + txtpassword.Text + "' ";
                    DBHelper.DBHelper.command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn);
                    DBHelper.DBHelper.reader = DBHelper.DBHelper.command.ExecuteReader();

                    if (DBHelper.DBHelper.reader.HasRows)
                    {
                        DBHelper.DBHelper.reader.Read();
                        txtusername.Text = (DBHelper.DBHelper.reader["username"].ToString());
                        txtpassword.Text = (DBHelper.DBHelper.reader["password"].ToString());

                        MessageBox.Show("Login successful!", "Access Granted", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        sendtext = txtusername.Text;
                        timer2.Enabled = true;
                        timer2.Start();
                        timer2.Interval = 1;
                        progressBar1.Maximum = 200;
                        timer2.Tick += new EventHandler(timer2_Tick);


                    }
                    else
                    {
                        MessageBox.Show("Invalid username and/or password!", "Invalid Credentials", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    Connection.Connection.conn.Close();
                }
            }





            catch (Exception ex)
            {
                Connection.Connection.conn.Close();
                MessageBox.Show(ex.Message, "Invalid Credentials", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {


                if (progressBar1.Value != 200)
                {
                    progressBar1.Value++;
                }
                else
                {
                    timer1.Stop();
                    progressBar1.Value = 0;

                    Menu m = new Menu();
                    m.Show();
                    this.Hide();

                }

            }
            catch
            {

            }
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void txtusername_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtpassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {


        }

        private void closebtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }



        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Graphics mgraphics = e.Graphics;
            Pen pen = new Pen(Color.FromArgb(205, 255, 216), 1);

            Rectangle Area = new Rectangle(0, 0, this.Width - 1, this.Height - 1);
            LinearGradientBrush lgb = new LinearGradientBrush(Area, Color.FromArgb(205, 255, 216), Color.FromArgb(148, 185, 255), LinearGradientMode.Vertical);
            mgraphics.FillRectangle(lgb, Area);
            mgraphics.DrawRectangle(pen, Area);

        }



        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.BackColor = Color.FromArgb(100, 0, 0, 0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SignUp s = new SignUp();
            s.Show();
            this.Hide();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value != 200)
            {
                progressBar1.Value++;
            }
            else
            {
                timer2.Stop();
                progressBar1.Value = 0;

                Yom_Apparel y = new Yom_Apparel();
                y.Show();
                this.Hide();
            }
        }
    }
}

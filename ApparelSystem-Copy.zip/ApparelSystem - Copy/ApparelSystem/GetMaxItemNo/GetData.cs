﻿using ApparelSystem.Connection;
using ApparelSystem.GetMaxItemNo;
using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApparelSystem.GetMaxItemNo
{
    internal class GetData
    {
        public static void getMaxItem()
        {
            try
            {
                string sql = "Select MAX(Itemno)from inventory";
                Connection.Connection.DB();
                GlobalDeclaration.command = new OleDbCommand(sql, Connection.Connection.conn);
                GlobalDeclaration.reader = GlobalDeclaration.command.ExecuteReader();
                if (GlobalDeclaration.reader.Read())
                {
                    sql = GlobalDeclaration.reader[0].ToString();
                    if (sql == "")
                    {
                        GlobalDeclaration.Itemno = 1;
                    }
                    else
                    {
                        GlobalDeclaration.Itemno = Convert.ToInt32(GlobalDeclaration.reader[0].ToString()) + 1;
                    }
                    GlobalDeclaration.reader.Close();
                }
                Connection.Connection.conn.Close();
            }
            catch (Exception ex)
            {
                Connection.Connection.conn.Close();
                MessageBox.Show("Error ---> GET MAX ID" + ex.Message);
            }

        }
        public static void getMaxORNO()
        {
            try
            {
                string sql = "Select MAX(OrderNo) from sales";
                Connection.Connection.DB();
                GlobalDeclaration.command = new OleDbCommand(sql, Connection.Connection.conn);
                GlobalDeclaration.reader = GlobalDeclaration.command.ExecuteReader();
                if (GlobalDeclaration.reader.Read())
                {
                    sql = GlobalDeclaration.reader[0].ToString();
                    if (sql == "")
                    {
                        GlobalDeclaration.OrderNo = 10001;
                    }
                    else
                    {
                        GlobalDeclaration.OrderNo = Convert.ToInt32(GlobalDeclaration.reader[0].ToString());
                    }
                    GlobalDeclaration.reader.Close();
                }
                Connection.Connection.conn.Close();
            }
            catch (Exception ex)
            {
                Connection.Connection.conn.Close();
                MessageBox.Show("Error ---> GET MAX ORNo" + ex.Message);
            }
        }
    }
}

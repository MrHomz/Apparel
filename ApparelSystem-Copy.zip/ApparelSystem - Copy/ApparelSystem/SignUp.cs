﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace ApparelSystem
{
    public partial class SignUp : Form
    {
        private string Sql;
        
        public SignUp()
        {
            InitializeComponent();
        }

        private void SignUp_Load(object sender, EventArgs e)
        {

        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            try
            {
                Sql = "INSERT INTO [Customer] ([Username], [Password], [FullName], [ContactNo]) "
                      + "VALUES('" + txtusername.Text + "', '" + txtpassword.Text + "', '" + txtFullName.Text + "', '" + txtContact.Text + "') ";
                DBHelper.DBHelper.ModifyRecord(Sql);

                MessageBox.Show("Sign Up successfully", "Sign up", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Form1 log = new Form1();
                log.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
    
}

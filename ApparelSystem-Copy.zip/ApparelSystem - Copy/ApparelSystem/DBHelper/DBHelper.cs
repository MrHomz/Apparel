﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;

namespace ApparelSystem.DBHelper
{
    internal class DBHelper
    {
        public static string gen = "";
        public static OleDbCommand command;
        public static OleDbConnection conn;
        public static OleDbDataReader reader;

        public static void fill(string q, DataGridView data_gv)
        {
            try
            {
                Connection.Connection.DB();
                DataTable dt = new DataTable();
                OleDbDataAdapter data = null;
                OleDbCommand command = new OleDbCommand(q, Connection.Connection.conn);
                data = new OleDbDataAdapter(command);
                data.Fill(dt);
                data_gv.DataSource = dt;
                Connection.Connection.conn.Close();

            }
            catch (Exception ex)
            {
                Connection.Connection.conn.Close();
                MessageBox.Show(ex.Message, "Error Fill Data GridView", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        public static void ModifyRecord(String updates)
        {
            try
            {
                Connection.Connection.DB();
                OleDbCommand command = new OleDbCommand(updates, Connection.Connection.conn);
                command.ExecuteNonQuery();
                Connection.Connection.conn.Close();
            }
            catch (Exception ex)
            {
                Connection.Connection.conn.Close();
                MessageBox.Show("Error --->" + updates + ex.Message);
            }
        }
    }
}

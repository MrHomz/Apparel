﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApparelSystem
{
    public partial class Comments : Form
    {
        public Comments()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.Visible = false;
        }
    }
}

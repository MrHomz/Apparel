﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.WebRequestMethods;


namespace ApparelSystem
{
    public partial class Yom_Apparel : Form
    {
        private string Sql;

        double total;
        public Yom_Apparel()
        {


            InitializeComponent();
        }
        private void Yom_Apparel_Load(object sender, EventArgs e)
        {

            panel1.BackColor = Color.FromArgb(100, 0, 0, 0);
            Sql = "SELECT * from inventory";
            DBHelper.DBHelper.fill(Sql, dataGridView1);
            GetMaxItemNo.GetData.getMaxItem();
            txtItemNo.Text = GetMaxItemNo.GlobalDeclaration.Itemno.ToString();


        }

        private void btnaddtocart_Click(object sender, EventArgs e)
        {

            double quantity = Convert.ToDouble(txtItemNo.Text);
            double price = Convert.ToDouble(txtprice.Text);
            double Stock = Convert.ToDouble(txtStock.Text);

            try
            {
                if (quantity > Stock)
                {

                    MessageBox.Show("Quantity is more than available in stocks", "Stocks Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    total = quantity * price;
                    txtTotal.Text = total.ToString("N2");
                    data_gv.Rows.Add(txtItemNo.Text, cmbclothing.Text, txtquantity.Text, txtStock.Text
                        , txtprice.Text, txtTotal.Text);

                }



            }
            catch
            {
                MessageBox.Show("Please Select Rent", "Select Bikes", MessageBoxButtons.OK, MessageBoxIcon.Information);


            }
        }
        private void clearfields()
        {

            txtItemNo.Clear();
            txtquantity.Clear();

            txtprice.Clear();




        }

        private void cmbclothing_SelectedIndexChanged(object sender, EventArgs e)
        {


            if (cmbclothing.Text == "Ordinary Tshirt")
            {

                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Clothing\\billabong-rotor-fill-short-sleeve-t-shirt.jpg");



            }
            else if (cmbclothing.Text == "Dri-fit Shirt")
            {


                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Clothing\\dri-fit.jpg");
            }
            else if (cmbclothing.Text == "Sleeveless ")
            {


                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Clothing\\hurley-everyday-washed-palm-stripes-sleeveless-t-shirt.jpg");


            }
            else if (cmbclothing.Text == "Wind Breaker")
            {


                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Clothing\\adidas-sportswear-tiro-windbreaker-jacket.jpg");
            }
            else if (cmbclothing.Text == "Hoodies")
            {


                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Clothing\\salty-crew-bruce-tech.jpg");
            }
            else if (cmbclothing.Text == "Sweater")
            {


                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Clothing\\oxbow-p0-pivega-essential-v-neck-sweater.jpg");
            }
            else if (cmbclothing.Text == "Chino Short")
            {

                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Shorts\\etnies-classic-chino-shorts.jpg");
            }
            else if (cmbclothing.Text == "Cargo Short")
            {


                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Shorts\\element-legion-cargo-cargo-shorts.jpg");
            }
            else if (cmbclothing.Text == "Surfing Short")
            {


                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Shorts\\zoot-board-9-shorts.jpg");
            }
            else if (cmbclothing.Text == "Cycling Short")
            {




                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Shorts\\bicycle-line-universo-shorts.jpg");
            }
            else if (cmbclothing.Text == "Trunk Short")
            {


                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Shorts\\newwood-trunk-swimming-shorts.jpg");

            }
        }








        private void btnupdate_Click(object sender, EventArgs e)
        {


            Sql = "UPDATE  [sales] SET [OrderNo] = '" + txtItemNo.Text
                + "', [Clothing] = '" + cmbclothing.Text
                + "', [Quantity] = '" + txtquantity.Text + ""
                + " WHERE [Price] = " + txtprice.Text + ";";

            DBHelper.DBHelper.ModifyRecord(Sql);
            MessageBox.Show("Data has been updated...", "Update Data", MessageBoxButtons.OK, MessageBoxIcon.Information);

            Yom_Apparel_Load(sender, e);



        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            {
                /* var res = MessageBox.Show("Are you sure you want to delete this record? ",
                  "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                  if (res == DialogResult.Yes)
                  {
                      Sql = "Delete * from sales WHERE OrderNo =" + txtOrderno.Text + "";
                      DBHelper.DBHelper.ModifyRecord(Sql);
                      Yom_Apparel_Load(sender, e);
                      clearfields();*/
            }
        }



        private void data_gv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            try
            {
                txtItemNo.Text = data_gv[0, e.RowIndex].Value.ToString();
                cmbclothing.Text = data_gv[1, e.RowIndex].Value.ToString();
                txtquantity.Text = data_gv[2, e.RowIndex].Value.ToString();
                txtStock.Text = data_gv[3, e.RowIndex].Value.ToString();
                txtprice.Text = data_gv[4, e.RowIndex].Value.ToString();
                txtPartial.Text = data_gv[5, e.RowIndex].Value.ToString();


            }
            catch
            {

            }

        }
        public void getsum()
        {
            double sum = 0;
            for (int i = 0; i < data_gv.RowCount - 1; i++)
            {
                sum += Convert.ToDouble(data_gv.Rows[i].Cells[i].Value);
            }
            txtTotal.Text = sum.ToString("N2");
        }



        private void button3_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtItemNo.Text = dataGridView1[0, e.RowIndex].Value.ToString();
            cmbclothing.Text = dataGridView1[1, e.RowIndex].Value.ToString();
            txtprice.Text = dataGridView1[2, e.RowIndex].Value.ToString();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

       
    }
    
}

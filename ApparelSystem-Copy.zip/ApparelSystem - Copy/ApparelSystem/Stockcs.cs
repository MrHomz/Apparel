﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace ApparelSystem
{
    public partial class Stockcs : Form
    {

        private string Sql = "";

        public Stockcs()
        {
            InitializeComponent();
        }

        private void Stockcs_Load(object sender, EventArgs e)
        {
            panel1.BackColor = Color.FromArgb(100, 0, 0, 0);
            Sql = "SELECT * from inventory";
            DBHelper.DBHelper.fill(Sql, dataGridView1);
            GetMaxItemNo.GetData.getMaxItem();
            txtItemNo.Text = GetMaxItemNo.GlobalDeclaration.Itemno.ToString();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtItemNo.Text != "" && cmbclothing.Text != ""  && txtSprice.Text != "" && txtStock.Text != "")
                {
                    Sql = "INSERT INTO [inventory] ([Itemno], [Clothing], [Sprice], [Stock])" +
                          " VALUES ('" + txtItemNo.Text + "', '"
                          + cmbclothing.Text + "', '"
                          + txtSprice.Text + "', '"
                          + txtStock.Text 
                          + "')";

                    DBHelper.DBHelper.ModifyRecord(Sql);
                    MessageBox.Show("Data has been added...", "Save new stock ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Stockcs_Load(sender, e);

                    clearfields();
                }
            }
            catch (Exception ex)
            {
                // Handle any exception that might occur during the insertion process.
                MessageBox.Show("An error occurred while adding data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void clearfields()
        {

            txtItemNo.Clear();
            cmbclothing.Text = "";
           
            txtSprice.Clear();
            txtStock.Clear();
            
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            Sql = "UPDATE [inventory] SET "  + " [Clothing] = '" + cmbclothing.Text
             
             + "', [Sprice] = '" + txtSprice.Text
             + "', [Small] = '" + txtStock.Text
              + "' WHERE [Itemno] = " + int.Parse(txtItemNo.Text);

            DBHelper.DBHelper.ModifyRecord(Sql);
            MessageBox.Show("Data has been updated...", "Update Data", MessageBoxButtons.OK, MessageBoxIcon.Information);

            Stockcs_Load(sender, e);
        }

            private void btndelete_Click(object sender, EventArgs e)
        {
            var res = MessageBox.Show("Are you sure you want to delete this record? ",
               "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                Sql = "Delete * from inventory WHERE Itemno =" + txtItemNo.Text + "";
                DBHelper.DBHelper.ModifyRecord(Sql);
                Stockcs_Load(sender, e);
                clearfields();
            }


        
    }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtItemNo.Text = dataGridView1[0, e.RowIndex].Value.ToString();
                cmbclothing.Text = dataGridView1[1, e.RowIndex].Value.ToString();
                txtSprice.Text = dataGridView1[2, e.RowIndex].Value.ToString();
                txtStock.Text = dataGridView1[3, e.RowIndex].Value.ToString();
                

            

            }
            catch
            {

            }

        }

        private void btnButton_Click(object sender, EventArgs e)
        {
            clearfields();
        }

        private void menuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Menu m = new Menu();
            m.Show();
            this.Hide();

        }

        private void btnmenu_Click(object sender, EventArgs e)
        {
            Menu m = new Menu();
            m.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cmbclothing_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbclothing.Text == "Ordinary Tshirt")
            {
                

                
                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Clothing\\billabong-rotor-fill-short-sleeve-t-shirt.jpg");



            }
            else if (cmbclothing.Text == "Dri-fit Shirt")
            {

               
                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Clothing\\dri-fit.jpg");
            }
            else if (cmbclothing.Text == "Sleeveless ")
            {

                
                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Clothing\\hurley-everyday-washed-palm-stripes-sleeveless-t-shirt.jpg");


            }
            else if (cmbclothing.Text == "Wind Breaker")
            {

                
                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Clothing\\adidas-sportswear-tiro-windbreaker-jacket.jpg");
            }
            else if (cmbclothing.Text == "Hoodies")
            {

                
                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Clothing\\salty-crew-bruce-tech.jpg");
            }
            else if (cmbclothing.Text == "Sweater")
            {

                
                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Clothing\\oxbow-p0-pivega-essential-v-neck-sweater.jpg");
            }
            else if (cmbclothing.Text == "Chino Short")
            {

                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Shorts\\etnies-classic-chino-shorts.jpg");
            }
            else if (cmbclothing.Text == "Cargo Short")
            {


                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Shorts\\element-legion-cargo-cargo-shorts.jpg");
            }
            else if (cmbclothing.Text == "Surfing Short")
            {


                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Shorts\\zoot-board-9-shorts.jpg");
            }
            else if (cmbclothing.Text == "Cycling Short")
            {




                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Shorts\\bicycle-line-universo-shorts.jpg");
            }
            else if (cmbclothing.Text == "Trunk Short")
            {


                pictureBox1.Image = new Bitmap("C:\\Users\\gabriela bianca\\Downloads\\Shorts\\newwood-trunk-swimming-shorts.jpg");

            }
        }


    }
    }
    


